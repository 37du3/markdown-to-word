chrome.commands.onCommand.addListener(e=>{}),chrome.runtime.onMessage.addListener((e,s,m)=>(m({success:!0}),!0));
//# sourceMappingURL=background.js.map
