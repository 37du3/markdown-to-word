import{_ as e,d as o}from"./DocxConverter-pGkPUL0-.js";var t=e((e,t)=>{let n;"sandbox"===t&&(n=o("#i"+e));return o("sandbox"===t?n.nodes()[0].contentDocument.body:"body").select(`[id="${e}"]`)},"getDiagramElement");export{t as g};
//# sourceMappingURL=chunk-55IACEB6-DYTSyx98.js.map
