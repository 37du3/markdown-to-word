var t;import{_ as r}from"./DocxConverter-pGkPUL0-.js";var s=(r(t=class{constructor(t){this.init=t,this.records=this.init()}reset(){this.records=this.init()}},"ImperativeState"),t);export{s as I};
//# sourceMappingURL=chunk-QZHKN3VN-B_ZnvdU8.js.map
