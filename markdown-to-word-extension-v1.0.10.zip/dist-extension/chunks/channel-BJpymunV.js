import{ap as a,aq as o}from"./DocxConverter-CyCGyvoG.js";const r=(r,s)=>a.lang.round(o.parse(r)[s]);export{r as c};
//# sourceMappingURL=channel-BJpymunV.js.map
