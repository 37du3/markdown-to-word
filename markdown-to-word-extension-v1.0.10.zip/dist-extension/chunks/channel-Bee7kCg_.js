import{ap as a,aq as o}from"./DocxConverter-pGkPUL0-.js";const r=(r,s)=>a.lang.round(o.parse(r)[s]);export{r as c};
//# sourceMappingURL=channel-Bee7kCg_.js.map
