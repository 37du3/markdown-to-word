function e(e,a){switch(arguments.length){case 0:break;case 1:this.range(e);break;default:this.range(a).domain(e)}return this}export{e as i};
//# sourceMappingURL=init-C0SZ43gy.js.map
