import{ap as a,aq as o}from"./DocxConverter-BYUTsroD.js";const r=(r,s)=>a.lang.round(o.parse(r)[s]);export{r as c};
//# sourceMappingURL=channel-Bk9vMVyu.js.map
