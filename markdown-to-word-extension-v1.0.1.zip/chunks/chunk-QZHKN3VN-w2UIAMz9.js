var t;import{_ as r}from"./DocxConverter-BYUTsroD.js";var s=(r(t=class{constructor(t){this.init=t,this.records=this.init()}reset(){this.records=this.init()}},"ImperativeState"),t);export{s as I};
//# sourceMappingURL=chunk-QZHKN3VN-w2UIAMz9.js.map
