import{_ as c}from"./DocxConverter-CyCGyvoG.js";function t(c,t){c.accDescr&&t.setAccDescription?.(c.accDescr),c.accTitle&&t.setAccTitle?.(c.accTitle),c.title&&t.setDiagramTitle?.(c.title)}c(t,"populateCommonDb");export{t as p};
//# sourceMappingURL=chunk-4BX2VUAB-DPSJKTs1.js.map
