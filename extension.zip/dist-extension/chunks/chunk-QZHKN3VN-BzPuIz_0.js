var t;import{_ as r}from"./DocxConverter-CyCGyvoG.js";var s=(r(t=class{constructor(t){this.init=t,this.records=this.init()}reset(){this.records=this.init()}},"ImperativeState"),t);export{s as I};
//# sourceMappingURL=chunk-QZHKN3VN-BzPuIz_0.js.map
